<div>
    <h1>Admin Dashboard</h1>
</div>
<?php /**PATH C:\xampp\htdocs\E-Commerce\resources\views/livewire/admin/admin-dashboard-component.blade.php ENDPATH**/ ?>