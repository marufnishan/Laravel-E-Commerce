<div>
    <h1>User/Clint Dashboard</h1>
</div>
<?php /**PATH C:\xampp\htdocs\E-Commerce\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>