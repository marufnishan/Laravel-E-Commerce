<div>
    <div class="container">
        <div class="row">
            
    <div class="wrap-show-advance-info-box style-1">
        <h3 class="title-box">Seller Products</h3>
        <div class="wrap-products">
            <div class="wrap-product-tab tab-style-1">
                <div class="tab-contents">
                    <div class="tab-content-item active" id="digital_1a">

                        <?php $__currentLoopData = $sellerproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sellerproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mcol-6 col-md-2 col-sm-6 product product-style-2 equal-elem " style="height: 300px;">
                            <div class="product-thumnail">
                                <a href="<?php echo e(route('product.details',['slug'=>$sellerproduct->slug])); ?>"
                                    title="<?php echo e($sellerproduct->name); ?>">
                                    <figure><img
                                            src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($sellerproduct->image); ?>"
                                            width="800" height="800" alt="<?php echo e($sellerproduct->name); ?>"></figure>
                                </a>
                                <div class="wrap-btn">
                                    <a href="<?php echo e(route('product.details',['slug'=>$sellerproduct->slug])); ?>"
                                        class="function-link">quick view</a>
                                </div>
                                <div class="group-flash">
                                    <span class="flash-item new-label">new</span>
                                </div>
                            </div>
                            <div class="product-info">
                                <a href="<?php echo e(route('product.details',['slug'=>$sellerproduct->slug])); ?>"
                                    class="product-name"><span><?php echo e($sellerproduct->name); ?></span></a>
                                <div class="wrap-price"><span
                                        class="product-price">৳<?php echo e($sellerproduct->regular_price); ?></span></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Maruf Nishan\Desktop\Defance\Laravel-E-Commerce\resources\views/livewire/seller-shop-component.blade.php ENDPATH**/ ?>