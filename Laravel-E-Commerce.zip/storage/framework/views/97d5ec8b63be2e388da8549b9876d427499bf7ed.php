<div>
<style>
        #dashboard::-webkit-scrollbar {
  display: none;
}

#sidebar::-webkit-scrollbar {
  display: none;

}   
.sidebar {
            height: 82vh;
        }
@media  screen and (max-height: 700px) {
            .sidebar {
            height: 82vh !important;
        }
    }
    </style>

    <div class="container-fluid">
        <div class="row ">
            <div id="main">
                <div class="col-md-12" style="margin: 0; padding:0; background:black "><button class="openbtn"
                        onclick="openNav()">☰ DASHBOARD</button></div>
                <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, []); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>

            <div class="col-md-12" id="dashboard" style="height:80vh; overflow-y: scroll; padding:0px; margin:0; ">
                <div class="row">
                    <div class="panel panel-default">
                        <div class="panel-heading" style="background: linear-gradient(to right, #74ebd5, #acb6e5);     padding: 13px 31px;">
                            Profile
                        </div>
                        <div class="panel-body">

                            <?php if(Session::has('update_message')): ?>
                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('update_message')); ?></div>
                            <?php endif; ?>
                            <div class="col-md-4">
                                <?php if($seller->seller->image): ?>
                                <img src="<?php echo e(asset('assets/images/sellers')); ?>/<?php echo e($seller->seller->image); ?>" width="100%" />
                                <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/profile/profile.png')); ?>" width="100%" />
                                <?php endif; ?>
                            </div>
                            <div class="col-md-8">
                                <h3>Name : <?php echo e($seller->name); ?></h3>
                                <p><b>Shop Name : </b><?php echo e($seller->seller->shop_name); ?></p>
                                <img src="<?php echo e(asset('assets/images/shops')); ?>/<?php echo e($seller->seller->shop_thumbnail); ?>" width="120" height="120" class="my-3"  />
                                <p><b>Email : </b><?php echo e($seller->email); ?></p>
                                <p><b>Phone : </b><?php echo e($seller->phone); ?></p>
                                <hr>
                                <p><b>NID : </b><?php echo e($seller->seller->nid); ?></p>
                                <p><b>Address : </b><?php echo e($seller->seller->address); ?></p>
                                <p><b>City : </b><?php echo e($seller->seller->city); ?></p>
                                <p><b>Province : </b><?php echo e($seller->seller->province); ?></p>
                                <p><b>Country : </b><?php echo e($seller->seller->country); ?></p>
                                <p><b>Zip Code : </b><?php echo e($seller->seller->zipcode); ?></p>
                                <p><b>Service Location : </b><?php echo e($seller->seller->service_location); ?></p>
                                <a href="<?php echo e(route('seller.editprofile')); ?>" class="btn btn-info pull-right">Update
                                    Profile</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH C:\Users\Maruf Nishan\Desktop\Defance\Laravel-E-Commerce\resources\views/livewire/seller/seller-profile-component.blade.php ENDPATH**/ ?>