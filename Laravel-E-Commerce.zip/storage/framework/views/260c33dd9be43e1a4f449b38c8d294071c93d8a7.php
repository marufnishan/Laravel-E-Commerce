<main id="main">
    <div class="container-fluid" id="banner">

        <!--MAIN SLIDE-->
        <div class="wrap-main-slide">
            <div class="slide-carousel owl-carousel style-nav-1" data-items="1" data-loop="1" data-nav="true"
                data-dots="false">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item-slide">
                    <img src="<?php echo e(asset('assets/images/sliders')); ?>/<?php echo e($slide->image); ?>" alt="" class="img-slide">
                    <div class="slide-info slide-3">
                        <h2 class="f-title"> <b><?php echo e($slide->title); ?></b></h2>
                        <span class="subtitle"><?php echo e($slide->subtitle); ?></span>
                        <p class="sale-info">Only price: <span class="price">৳<?php echo e($slide->price); ?></span></p>
                        <a href="<?php echo e($slide->link); ?>" class="btn-link">Shop Now</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!--BANNER-->
        <div>
            <footer id="footer">
                <div class="wrap-footer-content footer-style-1">

                    <div class="wrap-function-info">
                        <div class="container">
                            <div class="row">
                                <ul>
                                    <li class="fc-info-item">
                                        <i class="fa fa-car" aria-hidden="true"></i>
                                        <div class="wrap-left-info">
                                            <h4 class="fc-name">Free Shipping</h4>
                                            <p class="fc-desc">Free On Oder Over ৳99</p>
                                        </div>

                                    </li>
                                    <li class="fc-info-item">
                                        <i class="fa fa-usd" aria-hidden="true"></i>
                                        <div class="wrap-left-info">
                                            <h4 class="fc-name">Money Returns</h4>
                                            <p class="fc-desc">30 Days money return</p>
                                        </div>

                                    </li>
                                    <li class="fc-info-item">
                                        <i class="fa fa-credit-card-alt" aria-hidden="true"></i>
                                        <div class="wrap-left-info">
                                            <h4 class="fc-name">Safe Payment</h4>
                                            <p class="fc-desc">Safe your online payment</p>
                                        </div>

                                    </li>
                                    <li class="fc-info-item">
                                        <i class="fa fa-clock-o" aria-hidden="true"></i>
                                        <div class="wrap-left-info">
                                            <h4 class="fc-name">Online Suport</h4>
                                            <p class="fc-desc">We Have Support 24/7</p>
                                        </div>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
            </footer>
        </div>
        <div class="container">
            <!--Product Categories-->
            <div class="wrap-show-advance-info-box style-1">
                <h3 class="title-box">Product Categories</h3>
                <div class="wrap-products">
                    <div class="wrap-product-tab tab-style-1">
                        <div class="tab-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="#category_<?php echo e($category->id); ?>"
                                class="tab-control-item <?php echo e($key==0 ? 'active':''); ?>"><?php echo e($category->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <div class="tab-contents">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-content-item <?php echo e($key==0 ? 'active':''); ?>" id="category_<?php echo e($category->id); ?>">
                                <div class="wrap-products slide-carousel owl-carousel style-nav-1 equal-container"
                                    data-items="5" data-loop="false" data-nav="true" data-dots="false"
                                    data-responsive='{"0":{"items":"2"},"480":{"items":"3"},"768":{"items":"4"},"992":{"items":"5"},"1200":{"items":"5"}}'>

                                    <?php
                                    $c_products =
                                    DB::table('products')->where('category_id',$category->id)->get()->take($no_of_products);
                                    ?>
                                    <?php $__currentLoopData = $c_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="product product-style-2 equal-elem ">
                                        <div class="product-thumnail">
                                            <a href="<?php echo e(route('product.details',['slug'=>$c_product->slug])); ?>"
                                                title="<?php echo e($c_product->name); ?>">
                                                <figure><img
                                                        src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($c_product->image); ?>"
                                                        width="800" height="800" alt="<?php echo e($c_product->name); ?>"></figure>
                                            </a>
                                            <div class="wrap-btn">
                                                <a href="<?php echo e(route('product.details',['slug'=>$c_product->slug])); ?>"
                                                    class="function-link">quick view</a>
                                            </div>
                                        </div>
                                        <div class="product-info">
                                            <a href="<?php echo e(route('product.details',['slug'=>$c_product->slug])); ?>"
                                                class="product-name"><span><?php echo e($c_product->name); ?></span></a>
                                            <div class="wrap-price"><span
                                                    class="product-price">৳<?php echo e($c_product->regular_price); ?></span></div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!--Latest Products-->
            <div class="wrap-show-advance-info-box style-1">
                <h3 class="title-box">Latest Products</h3>
                <div class="wrap-products">
                    <div class="wrap-product-tab tab-style-1">
                        <div class="tab-contents">
                            <div class="tab-content-item active" id="digital_1a">

                                <?php $__currentLoopData = $lproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mcol-6 col-md-2 col-sm-6 product product-style-2 equal-elem " style="height: 300px;">
                                    <div class="product-thumnail">
                                        <a href="<?php echo e(route('product.details',['slug'=>$lproduct->slug])); ?>"
                                            title="<?php echo e($lproduct->name); ?>">
                                            <figure><img
                                                    src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($lproduct->image); ?>"
                                                    width="800" height="800" alt="<?php echo e($lproduct->name); ?>"></figure>
                                        </a>
                                        <div class="wrap-btn">
                                            <a href="<?php echo e(route('product.details',['slug'=>$lproduct->slug])); ?>"
                                                class="function-link">quick view</a>
                                        </div>
                                        <div class="group-flash">
                                            <span class="flash-item new-label">new</span>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="<?php echo e(route('product.details',['slug'=>$lproduct->slug])); ?>"
                                            class="product-name"><span><?php echo e($lproduct->name); ?></span></a>
                                        <div class="wrap-price"><span
                                                class="product-price">৳<?php echo e($lproduct->regular_price); ?></span></div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--  End Latest product -->

            <!-- Sale Product Start  -->
            <?php if($sproducts->count() > 0 && $sale->status == 1 && $sale->sale_date > Carbon\Carbon::now()): ?>
            <div class="wrap-show-advance-info-box style-1">
                <h3 class="title-box">On Sale</h3>
                <?php $__currentLoopData = $sproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mcol-6 col-md-2 col-sm-6 product product-style-2 equal-elem " style="height: 300px;">
                    <div class="product-thumnail">
                        <a href="<?php echo e(route('product.details',['slug'=>$sproduct->slug])); ?>" title="<?php echo e($sproduct->name); ?>">
                            <figure><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($sproduct->image); ?>" width="800"
                                    height="800" alt="T-Shirt Raw Hem Organic Boro Constrast Denim">
                            </figure>
                        </a>
                        <div class="wrap-btn">
                            <a href="<?php echo e(route('product.details',['slug'=>$sproduct->slug])); ?>" class="function-link">quick
                                view</a>
                        </div>
                        <div class="group-flash">
                            <span class="flash-item sale-label">sale</span>
                        </div>
                    </div>
                    <div class="product-info">
                        <a href="<?php echo e(route('product.details',['slug'=>$sproduct->slug])); ?>"
                            class="product-name"><span><?php echo e($sproduct->name); ?></span></a>
                        <div class="wrap-price"><ins>
                                <p class="product-price">৳<?php echo e($sproduct->sale_price); ?></p>
                            </ins> <del>
                                <p class="product-price">৳<?php echo e($sproduct->regular_price); ?></p>
                            </del></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <!--  End Sale product -->

            <!--popular Products-->
            <div class="wrap-show-advance-info-box style-1">
                <h3 class="title-box">Popular Products</h3>
                <div class="wrap-products">
                    <div class="wrap-product-tab tab-style-1">
                        <div class="tab-contents">
                            <div class="tab-content-item active" id="digital_1a">

                                <?php $__currentLoopData = $pproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mcol-6 col-md-2 col-sm-6 product product-style-2 equal-elem " style="height: 300px;">
                                    <div class="product-thumnail">
                                        <a href="<?php echo e(route('product.details',['slug'=>$pproduct->slug])); ?>"
                                            title="<?php echo e($pproduct->name); ?>">
                                            <figure><img
                                                    src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($pproduct->image); ?>"
                                                    width="800" height="800" alt="<?php echo e($pproduct->name); ?>"></figure>
                                        </a>
                                        <div class="wrap-btn">
                                            <a href="<?php echo e(route('product.details',['slug'=>$pproduct->slug])); ?>"
                                                class="function-link">quick view</a>
                                        </div>
                                        <div class="group-flash">
                                            <span class="flash-item new-label">populer</span>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="<?php echo e(route('product.details',['slug'=>$pproduct->slug])); ?>"
                                            class="product-name"><span><?php echo e($pproduct->name); ?></span></a>
                                        <div class="wrap-price"><span
                                                class="product-price">৳<?php echo e($pproduct->regular_price); ?></span></div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--  End popular product -->
        </div>
</main>
<?php /**PATH C:\Users\Maruf Nishan\Desktop\Defance\Laravel-E-Commerce\resources\views/livewire/home-component.blade.php ENDPATH**/ ?>