<div>
    <style>
        .category-item{
            line-height: 50px;
            text-transform: uppercase;
            padding-right: 6px;
        }
        .category-item a{
            color: #666666;
        }
    </style>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="category-item">
                                <a href="<?php echo e(route('product.category',['category_slug'=>$category->slug])); ?>"
                                    class="cate-link2"><?php echo e($category->name); ?></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\Maruf Nishan\Desktop\Defance\Laravel-E-Commerce\resources\views/livewire/mo-category-component.blade.php ENDPATH**/ ?>