<div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3" style="padding: 20px">
                <div class="card" style="width: 18rem;">
                    <img class="card-img-top" src="<?php echo e(asset('assets/images/shops')); ?>/<?php echo e($seller->shop_thumbnail); ?>"
                        alt="Shop Thumbnail">
                    <div class="card-body">
                        <h5 class="card-title text-center"><?php echo e($seller->shop_name); ?></h5>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item text-center">Total Products : <?php echo e($seller->product->where('seller_id',$seller->seller_id)->count()); ?></li>
                    </ul>
                    <div class="card-body text-center">
                        <a href="<?php echo e(route('sellerShop',$seller->seller_id)); ?>" class="card-link"><button class="btn btn-info">Go To Shop</button></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>
<?php /**PATH C:\Users\Maruf Nishan\Desktop\Defance\Laravel-E-Commerce\resources\views/livewire/all-shops-component.blade.php ENDPATH**/ ?>